#ifndef TBYTE_H
#define TBYTE_H


namespace BlackT {


/**
 * Typedef for a "byte" type.
 * Alias of unsigned char.
 */
typedef unsigned char TByte;


};


#endif 
