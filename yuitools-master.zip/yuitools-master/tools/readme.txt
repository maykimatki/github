Battle Golfer Yui


asm			= text notes on menu/scripter


src
- atlas_src		= Atlas 1.06 mod (SRWEX edition)
- golfer_dumper		= text dumper
- golfer_packer		= bitmaps compressor


tools
1. 'Copy of Battle Golfer Yui (J) [c][!].bin' to tools

2a. dump TEXT.bat	= create TEXT files
2b. unpack BITMAPS.bat	= create BITMAP files

3. copy IMAGE.bat	= restore old backup

4a. insert TEXT.bat	= insert scripts to ROM
4b. repack BITMAPS.bat	= encode bitmaps to files
4c. insert ASM.bat	= insert bitmaps to ROM
